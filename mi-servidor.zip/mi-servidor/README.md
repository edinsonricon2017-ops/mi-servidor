# Servidor con Express

Este proyecto es un servidor básico usando Node.js y Express.

## Instalación
npm install

## Ejecución
node index.js

## Rutas
/ → Mensaje de bienvenida
/productos → Lista de productos en JSON
