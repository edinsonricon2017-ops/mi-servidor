const express = require('express');
const app = express();

// IMPORTANTE: habilitar carpeta public
app.use(express.static('public'));

// Puerto
const PORT = 3000;

// Ruta principal
app.get('/', (req, res) => {
    res.send('Bienvenido a mi servidor');
});

// Ruta productos
app.get('/productos', (req, res) => {
    const productos = [
        { id: 1, nombre: 'Guitarra', precio: 500000, imagen: '/img/guitarra.png' },
        { id: 2, nombre: 'Piano', precio: 1500000, imagen: '/img/piano.png' },
        { id: 3, nombre: 'Batería', precio: 1200000, imagen: '/img/bateria.png' }
    ];

    let html = `
    <html>
    <head>
        <title>Tienda de Música</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: #f4f6f9;
                margin: 0;
                padding: 0;
            }

            h1 {
                text-align: center;
                padding: 20px;
                background: #222;
                color: white;
                margin: 0;
            }

            .contenedor {
                display: flex;
                justify-content: center;
                flex-wrap: wrap;
                gap: 20px;
                padding: 20px;
            }

            .card {
                background: white;
                border-radius: 15px;
                width: 250px;
                box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                overflow: hidden;
                transition: transform 0.3s;
            }

            .card:hover {
                transform: scale(1.05);
            }

            .card img {
                width: 100%;
                height: 180px;
                object-fit: cover;
            }

            .card-body {
                padding: 15px;
                text-align: center;
            }

            .precio {
                color: green;
                font-weight: bold;
                font-size: 18px;
            }

            button {
                margin-top: 10px;
                padding: 10px;
                border: none;
                background: #007BFF;
                color: white;
                border-radius: 8px;
                cursor: pointer;
            }

            button:hover {
                background: #0056b3;
            }
        </style>
    </head>
    <body>
        <h1>🎵 Tienda de Instrumentos</h1>
        <div class="contenedor">
    `;

    productos.forEach(p => {
        html += `
        <div class="card">
            <img src="${p.imagen}" alt="${p.nombre}">
            <div class="card-body">
                <h3>${p.nombre}</h3>
                <p class="precio">$${p.precio.toLocaleString()}</p>
                <button onclick="alert('Producto agregado al carrito')">Comprar</button>
            </div>
        </div>
        `;
    });

    html += `
        </div>
    </body>
    </html>
    `;

    res.send(html);
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});